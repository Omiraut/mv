package com.controller;

import java.util.List;

import javax.persistence.metamodel.SetAttribute;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.model.EmpModel;
import com.model.logModel;
import com.services.Empservices;

@Controller
public class EmpController {

	@Autowired
	Empservices empservice;
	
	@RequestMapping("/logpage")
	public String logp()
	{
		return "Loginpage";
		
	}
	
	@RequestMapping("/empform")
	public String Reg()
	{
		return "EmpForm";
		
	}
	
	@RequestMapping(value="/saveemp", method=RequestMethod.POST)
	public String Saveemp(@ModelAttribute("emp") EmpModel emp,HttpSession session)
	{
		empservice.saveEmp(emp);
		session.setAttribute("data", "datas");
		return "Loginpage";
		
	}
	
	@RequestMapping(value="/dologin", method=RequestMethod.POST)
	public String login(@ModelAttribute("log") logModel log,HttpSession session)
	{
		List<EmpModel> list=empservice.log(log);
		if(list!=null)
		{
			String emm=empservice.getName(log.getUsername(),log.getPassword());
			session.setAttribute("name", emm);
			session.setAttribute("logsuccess", "success");
			session.setAttribute("seslog", log.getUsername());
			session.setAttribute("sespass", log.getPassword());
			return "redirect:/view";
		}
		else
			session.setAttribute("sesfail", "failed");
			return"Loginpage";
		
		
	}
	
	@RequestMapping("/view")
	public String GetAlldata(Model mo,HttpSession session)
	{
		String user=(String)session.getAttribute("seslog");
		String pass=(String)session.getAttribute("sespass");
		List<EmpModel> list=empservice.getAlldata(user,pass);
		mo.addAttribute("alldata", list);
		return "Dashboard";
		
	}
	@RequestMapping("/delete/{id}")
	public String Delete(@PathVariable int id,HttpSession session)
	
	{
		empservice.deleteById(id);
		session.setAttribute("delete", "deleted");
		return "redirect:/view";
		
	}
	
	@RequestMapping("/edit/{id}")
	public String Edit(@PathVariable int id,Model mo)
	{
		EmpModel emp=empservice.Editdata(id);
		mo.addAttribute("command",emp);
		return "EditFormTag";
		
	}
	@RequestMapping(value="update",method=RequestMethod.POST)
	public String Update(@ModelAttribute("emp") EmpModel  emp,HttpSession session)
	{
		empservice.updateById(emp);
		return "redirect:/view";
		
	}
}
