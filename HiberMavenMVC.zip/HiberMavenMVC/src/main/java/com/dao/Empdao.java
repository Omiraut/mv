package com.dao;

import java.util.List;

import com.model.EmpModel;
import com.model.logModel;

public interface Empdao {

	
	public List<EmpModel> getAlldata(String user, String pass);
	
	public void saveEmp(EmpModel emp);

	

	public List<EmpModel> log(logModel log);

	

	public String getName(String username, String password);

	public void deleteById(int id);

	public EmpModel Editdata(int id);

	public void updateById(EmpModel emp);

	

	

	
}
