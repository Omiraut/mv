package com.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.EmpModel;

import com.model.logModel;

@Repository
public class Empdaoimpl implements Empdao {

	@Autowired
	
	SessionFactory sessionFactory;
	

	

	public void saveEmp(EmpModel emp) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().save(emp);
	}

	public List<EmpModel> log(logModel log) {
		// TODO Auto-generated method stub
		String hql="from EmpModel where loginid ='"+log.getUsername()+"' and password ='"+log.getPassword()+"'";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		List<EmpModel> results = query.list();
		List<EmpModel> res = results.size()>0?results:null;
		return res;
	}

	

	public String getName(String username, String password) {
		// TODO Auto-generated method stub
		String hql="select name from EmpModel where loginid='"+username+"' and password='"+password+"'";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		String emm=(String) query.list().get(0);
		return emm;
	}

	public List<EmpModel> getAlldata(String user, String pass) {
		// TODO Auto-generated method stub
		String hql="from EmpModel ";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		List<EmpModel> list=query.list();
		return list;
	}

	public void deleteById(int id) {
		// TODO Auto-generated method stub
		EmpModel emp=sessionFactory.getCurrentSession().get(EmpModel.class, id);
		sessionFactory.getCurrentSession().delete(emp);
	}

	public EmpModel Editdata(int id) {
		// TODO Auto-generated method stub
		EmpModel emp=sessionFactory.getCurrentSession().get(EmpModel.class, id);
		return emp;
	}

	public void updateById(EmpModel emp) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().update(emp);
	}

}
