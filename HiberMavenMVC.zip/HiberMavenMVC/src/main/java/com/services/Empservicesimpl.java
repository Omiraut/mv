package com.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.Empdao;
import com.model.EmpModel;
import com.model.logModel;

@Service
public class Empservicesimpl implements Empservices {

	@Autowired
	Empdao dao;
	


@Transactional
	public void saveEmp(EmpModel emp) {
		// TODO Auto-generated method stub
		dao.saveEmp(emp);
	}
@Transactional
public List<EmpModel> log(logModel log) {
	// TODO Auto-generated method stub
	List<EmpModel> list=dao.log(log);
	return list;
}



@Transactional
public String getName(String username, String password) {
	// TODO Auto-generated method stub
	String emm=dao.getName(username,password);
	return emm;
}

@Transactional
public List<EmpModel> getAlldata(String user, String pass) {
	// TODO Auto-generated method stub
	List<EmpModel> list=dao.getAlldata(user,pass);
	return list;
}
@Transactional
public void deleteById(int id) {
	// TODO Auto-generated method stub
	dao.deleteById(id);
}
@Transactional
public EmpModel Editdata(int id) {
	// TODO Auto-generated method stub
	EmpModel emp=dao.Editdata(id);
	return emp;
}

@Transactional
public void updateById(EmpModel emp) {
	// TODO Auto-generated method stub
	dao.updateById(emp);
}



	

}
